package joosc.ir.ast;

/**
 * An intermediate representation for statements
 */
public abstract class Stmt extends Node_c {
}
